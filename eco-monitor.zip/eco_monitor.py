#!/usr/bin/env python3
"""Эко-Монитор: сбор информации по темам из Telegram, ВКонтакте, Google News и RSS.
Этап 1: сборщики, автопоиск новых источников, ИИ-классификация, веб-панель."""
import asyncio, json, os, re, hashlib, sqlite3, time, logging, collections, calendar, html as htmlmod, urllib.parse
import aiohttp
from aiohttp import web
import feedparser
from telethon import TelegramClient, functions, types
from telethon.errors import SessionPasswordNeededError, FloodWaitError

BASE = os.path.dirname(os.path.abspath(__file__))
DATA = os.environ.get('ECO_DATA', os.path.join(BASE, 'data'))
TOKEN = os.environ.get('ECO_TOKEN', '')
HOST = os.environ.get('ECO_HOST', '127.0.0.1')
PORT = int(os.environ.get('ECO_PORT', '8080'))
os.makedirs(DATA, exist_ok=True)
CFG_PATH = os.path.join(DATA, 'config.json')
DB_PATH = os.path.join(DATA, 'eco.db')
UA = 'Mozilla/5.0 (X11; Linux x86_64) EcoMonitor/1.0'

# ---------- журнал ----------
LOG = collections.deque(maxlen=400)
class _DequeHandler(logging.Handler):
    def emit(self, r): LOG.append(self.format(r))
logging.basicConfig(level=logging.INFO, format='%(asctime)s %(levelname)s %(message)s')
_h = _DequeHandler(); _h.setFormatter(logging.Formatter('%(asctime)s  %(message)s', '%d.%m %H:%M'))
logging.getLogger().addHandler(_h)
logging.getLogger('telethon').setLevel(logging.WARNING)
log = logging.getLogger('eco')

# ---------- настройки ----------
SECRET_FIELDS = ('tg_api_hash', 'anthropic_key', 'vk_token', 'bot_token')
DEFAULT_CONFIG = {
    "tg_api_id": "", "tg_api_hash": "", "anthropic_key": "", "vk_token": "",
    "model": "claude-haiku-5-5",
    "interval_min": 30,
    "discovery_hours": 6,
    "tg_read_dialogs": True,
    "google_news": True,
    "vk_newsfeed": True,
    "auto_approve_min": 0,
    "keep_days": 120,
    "only_russia": True,
    "update_url": "https://github.com/DD-77B/ecomonitor/raw/main/eco-monitor.zip",
    "bot_token": "", "channel": "", "admin_chat": "",
    "slots": ["09:00", "13:00", "18:00", "21:00"], "tz_offset": 3,
    "writer_model": "claude-sonnet-5-5",
    "auto_draft_imp": 4,
    "auto_draft_per_day": 8,
    "cfg_version": 2,
    "post_style": ("Канал «ЧистоКонкретно» (ЧК) — острый, критичный взгляд на мусорную реформу, экологию и работу Минприроды. "
        "Тон: прямой, с позицией, иронией и неудобными вопросами к чиновникам, регоператорам и компаниям. "
        "Правила: критика опирается только на факты из материалов; чужие обвинения и оценки приписывай источнику "
        "(«по данным…», «жители утверждают…»); свою позицию подавай как мнение канала и вопросы, а не как установленный факт; "
        "без оскорблений, призывов к противоправным действиям и домыслов о личной жизни; не выдумывай цифры, даты и цитаты; "
        "пиши своими словами, не копируй текст источника; обращайся к читателю на «вы»."),
    "topics": [
        {"name": "Мусорная реформа", "keywords": ["мусор", "ТКО", "отходов", "отходы", "полигон", "свалк", "регоператор",
            "региональный оператор", "региональным оператором", "РЭО", "экосбор", "экологический сбор", "РОП", "сортиров",
            "раздельн", "мусоросжига", "МСЗ", "контейнерн"]},
        {"name": "Минприроды и надзор", "keywords": ["Минприроды", "Росприроднадзор", "министерство природных ресурсов",
            "министр природных ресурсов", "Росводресурс", "Рослесхоз", "Росгидромет", "природоохран"]},
        {"name": "Экология", "keywords": ["эколог", "загрязн", "выброс", "очистн", "вырубк", "лесной пожар", "лесные пожары",
            "заповедн", "нацпарк"]}
    ],
    "search_queries": ["мусорная реформа", "тариф на вывоз мусора", "свалка жалобы", "региональный оператор ТКО",
        "мусоросжигательный завод", "Минприроды России", "Росприроднадзор проверка", "экологический сбор",
        "раздельный сбор отходов", "полигон ТКО"],
    "discovery_queries": ["мусорная реформа", "экология", "отходы", "ТКО", "регоператор", "свалка", "Росприроднадзор",
        "экоактивисты", "переработка отходов"],
    "regions": [],
    "region_words": ["мусор", "свалка", "экология"],
    "region_templates": ["{r} чат", "{r} жители", "{r} подслушано", "{r} новости"],
    "tg_sources": [], "vk_groups": [], "rss": []
}

def load_cfg():
    cfg = json.loads(json.dumps(DEFAULT_CONFIG))
    if os.path.exists(CFG_PATH):
        try:
            with open(CFG_PATH, encoding='utf-8') as f: cfg.update(json.load(f))
        except Exception as e: log.error(f'Настройки не прочитаны: {e}')
    return cfg

def save_cfg():
    tmp = CFG_PATH + '.tmp'
    with open(tmp, 'w', encoding='utf-8') as f: json.dump(CFG, f, ensure_ascii=False, indent=1)
    os.replace(tmp, CFG_PATH)

CFG = load_cfg()
if int(CFG.get('cfg_version') or 1) < 2:   # с версии 2 авточерновики включены по умолчанию
    if not int(CFG.get('auto_draft_imp') or 0): CFG['auto_draft_imp'] = 4
    CFG['cfg_version'] = 2
    try: save_cfg()
    except Exception: pass

# ---------- база ----------
DBC = sqlite3.connect(DB_PATH); DBC.row_factory = sqlite3.Row
DBC.executescript('''
CREATE TABLE IF NOT EXISTS items(id INTEGER PRIMARY KEY, hash TEXT UNIQUE, src_type TEXT, src_id TEXT, src_title TEXT,
  url TEXT, ts INTEGER, text TEXT, kw TEXT, dups INTEGER DEFAULT 0, ai_status TEXT DEFAULT 'pending', relevance REAL,
  topic TEXT, region TEXT, kind TEXT, sentiment REAL, importance INTEGER, summary TEXT, added INTEGER);
CREATE INDEX IF NOT EXISTS i_ts ON items(ts);
CREATE INDEX IF NOT EXISTS i_ai ON items(ai_status);
CREATE TABLE IF NOT EXISTS state(k TEXT PRIMARY KEY, v TEXT);
CREATE TABLE IF NOT EXISTS posts(id INTEGER PRIMARY KEY, item_ids TEXT, fmt TEXT, body TEXT, status TEXT DEFAULT 'draft',
  sched_ts INTEGER, pub_ts INTEGER, tg_msg_id INTEGER, created INTEGER);
CREATE TABLE IF NOT EXISTS candidates(id INTEGER PRIMARY KEY, kind TEXT, handle TEXT, title TEXT, members INTEGER DEFAULT 0,
  is_group INTEGER DEFAULT 0, via TEXT, status TEXT DEFAULT 'new', resolved INTEGER DEFAULT 0, added INTEGER, UNIQUE(kind, handle));
''')

def state_get(k, d=None):
    r = DBC.execute('SELECT v FROM state WHERE k=?', (k,)).fetchone()
    return r[0] if r else d

def state_set(k, v):
    DBC.execute('INSERT OR REPLACE INTO state(k,v) VALUES(?,?)', (k, str(v)))

# ---------- текст ----------
PHONE = re.compile(r'(?:\+7|\b8)[\s\-(]*\d{3}[\s\-)]*\d{3}[\s\-]*\d{2}[\s\-]*\d{2}\b')
EMAIL = re.compile(r'[\w.+-]+@[\w-]+\.[\w.]+')
TAGS = re.compile(r'<[^>]+>')
_kw_cache = {}

def kw_rx(kw):
    if kw not in _kw_cache:
        if kw.isupper() and len(kw) <= 6:   # аббревиатуры (ТКО, РОП) — только целым словом и с учётом регистра
            _kw_cache[kw] = re.compile(r'(?<!\w)' + re.escape(kw) + r'(?!\w)')
        else:
            _kw_cache[kw] = re.compile(re.escape(kw), re.I)
    return _kw_cache[kw]

def match_topics(text):
    return [t['name'] for t in CFG['topics'] if any(kw_rx(k).search(text) for k in t['keywords'] if k.strip())]

def clean(t):
    """Маскирует телефоны и почту: в базе не хранятся персональные контакты."""
    return EMAIL.sub('[email]', PHONE.sub('[тел]', t or '')).strip()

def strip_html(s):
    return htmlmod.unescape(TAGS.sub(' ', s or '')).strip()

def norm_hash(t):
    t = re.sub(r'https?://\S+', '', t.lower())
    t = re.sub(r'\W+', ' ', t).strip()
    return hashlib.sha1(t[:400].encode()).hexdigest()

def save_item(src_type, src_id, src_title, url, ts, text, require_kw=True):
    text = clean(text)
    if len(text) < 30: return False
    kw = match_topics(text)
    if require_kw and not kw: return False
    h = norm_hash(text)
    try:
        DBC.execute('INSERT INTO items(hash,src_type,src_id,src_title,url,ts,text,kw,added) VALUES(?,?,?,?,?,?,?,?,?)',
                    (h, src_type, str(src_id), src_title or '', url or '', int(ts), text[:6000], ','.join(kw), int(time.time())))
        return True
    except sqlite3.IntegrityError:
        DBC.execute('UPDATE items SET dups=dups+1 WHERE hash=?', (h,))   # тот же текст в другом источнике = резонанс
        return False

# ---------- кандидаты в источники ----------
TME = re.compile(r'(?:t\.me|telegram\.me)/(?:s/)?([A-Za-z][A-Za-z0-9_]{4,31})\b')
MENTION = re.compile(r'(?<![\w@./])@([A-Za-z][A-Za-z0-9_]{4,31})\b')
VKLINK = re.compile(r'vk\.com/([A-Za-z0-9_.]{3,40})')
TG_SKIP = {'joinchat', 'addlist', 'share', 'addstickers', 'proxy', 'socks', 'setlanguage', 'addemoji', 'boost', 'iv'}
VK_SKIP = re.compile(r'^(wall|video|photo|album|topic|id\d|feed|im$|away|doc|audio|market|app|clip|story|search|login|@)', re.I)

def _norm_handle(h): return h.strip().lstrip('@').split('/')[-1].lower()

def add_candidate(kind, handle, title='', members=0, is_group=0, via='', resolved=0):
    handle = _norm_handle(handle)
    if not handle: return
    known = CFG['tg_sources'] if kind == 'tg' else CFG['vk_groups']
    if handle in {_norm_handle(s) for s in known}: return
    if kind == 'tg' and (handle in TG_SKIP or handle.endswith('bot')): return
    if kind == 'vk' and VK_SKIP.match(handle): return
    cur = DBC.execute('INSERT OR IGNORE INTO candidates(kind,handle,title,members,is_group,via,resolved,added) VALUES(?,?,?,?,?,?,?,?)',
                      (kind, handle, title, int(members or 0), int(is_group), via, int(resolved), int(time.time())))
    if cur.rowcount == 0 and resolved:
        DBC.execute('UPDATE candidates SET title=?, members=?, is_group=?, resolved=1 WHERE kind=? AND handle=? AND resolved=0',
                    (title, int(members or 0), int(is_group), kind, handle))

def mine_links(text, mentions=False):
    for h in TME.findall(text): add_candidate('tg', h, via='ссылка в сообщении')
    if mentions:
        for h in MENTION.findall(text): add_candidate('tg', h, via='упоминание')
    for h in VKLINK.findall(text): add_candidate('vk', h.rstrip('.'), via='ссылка в сообщении')

def approve_candidate(cid):
    r = DBC.execute('SELECT * FROM candidates WHERE id=?', (cid,)).fetchone()
    if not r: return
    lst = CFG['tg_sources'] if r['kind'] == 'tg' else CFG['vk_groups']
    if r['handle'] not in {_norm_handle(s) for s in lst}: lst.append(r['handle'])
    DBC.execute("UPDATE candidates SET status='approved' WHERE id=?", (cid,))

def auto_approve():
    m = int(CFG.get('auto_approve_min') or 0)
    if m <= 0: return
    rows = DBC.execute("SELECT id FROM candidates WHERE status='new' AND resolved=1 AND members>=?", (m,)).fetchall()
    for r in rows: approve_candidate(r['id'])
    if rows: save_cfg(); log.info(f'Автоматически добавлено источников: {len(rows)}')

def all_queries():
    return CFG['search_queries'] + [f'{r} {w}' for r in CFG['regions'] for w in CFG['region_words']]

def discovery_queries():
    return CFG['discovery_queries'] + [t.format(r=r) for r in CFG['regions'] for t in CFG['region_templates']]

# ---------- Telegram ----------
TG = {'client': None, 'creds': None, 'login': {}}

async def tg_client():
    creds = (str(CFG['tg_api_id']).strip(), CFG['tg_api_hash'].strip())
    if not all(creds): return None
    c = TG['client']
    if c and TG['creds'] != creds:
        await c.disconnect(); c = None
    if not c:
        c = TelegramClient(os.path.join(DATA, 'tg'), int(creds[0]), creds[1], device_model='EcoMonitor', app_version='1.0')
        TG['client'], TG['creds'] = c, creds
    if not c.is_connected(): await c.connect()
    return c

async def tg_ready():
    c = await tg_client()
    return c if c and await c.is_user_authorized() else None

async def tg_collect_entity(c, ent, title, username, thematic):
    is_chat = not getattr(ent, 'broadcast', False)
    key = f'tg:{ent.id}'
    last = int(state_get(key, 0))
    mx, n, saved = last, 0, 0
    async for m in c.iter_messages(ent, min_id=last, limit=(80 if last == 0 else 500)):
        mx = max(mx, m.id); n += 1
        txt = m.message or ''
        if not txt: continue
        if thematic: mine_links(txt)
        url = f'https://t.me/{username}/{m.id}' if username else f'https://t.me/c/{ent.id}/{m.id}'
        if save_item('tg_chat' if is_chat else 'tg', ent.id, title, url, m.date.timestamp(), txt):
            saved += 1
            if not thematic: mine_links(txt)
            mine_links(txt, mentions=True)
            try:
                fc = m.forward.chat if m.forward else None
                if fc and getattr(fc, 'username', None):
                    add_candidate('tg', fc.username, fc.title, getattr(fc, 'participants_count', 0) or 0,
                                  int(bool(getattr(fc, 'megagroup', False))), 'репост', 1)
            except Exception: pass
    state_set(key, mx)
    return n, saved

async def tg_collect():
    c = await tg_ready()
    if not c: return
    seen, tot_n, tot_s = set(), 0, 0
    for s in list(CFG['tg_sources']):
        u = _norm_handle(s)
        try:
            ent = await c.get_entity(u)
            seen.add(ent.id)
            n, sv = await tg_collect_entity(c, ent, getattr(ent, 'title', u), getattr(ent, 'username', None), True)
            tot_n += n; tot_s += sv
        except FloodWaitError as e:
            log.warning(f'Telegram просит паузу {e.seconds} с'); await asyncio.sleep(min(e.seconds, 120))
        except Exception as e:
            log.warning(f'Telegram @{u}: {e}')
        DBC.commit(); await asyncio.sleep(1)
    if CFG['tg_read_dialogs']:
        async for d in c.iter_dialogs():
            if not (d.is_group or d.is_channel) or d.entity.id in seen: continue
            try:
                n, sv = await tg_collect_entity(c, d.entity, d.name, getattr(d.entity, 'username', None), False)
                tot_n += n; tot_s += sv
            except FloodWaitError as e:
                log.warning(f'Telegram просит паузу {e.seconds} с'); await asyncio.sleep(min(e.seconds, 120))
            except Exception as e:
                log.warning(f'Telegram «{d.name}»: {e}')
            DBC.commit(); await asyncio.sleep(0.5)
    log.info(f'Telegram: просмотрено {tot_n}, сохранено по темам {tot_s}')

async def tg_discover():
    c = await tg_ready()
    if not c: return
    found = 0
    for q in discovery_queries():
        try:
            res = await c(functions.contacts.SearchRequest(q=q, limit=40))
            for ch in res.chats:
                if getattr(ch, 'username', None):
                    add_candidate('tg', ch.username, ch.title, getattr(ch, 'participants_count', 0) or 0,
                                  int(bool(getattr(ch, 'megagroup', False))), f'поиск: {q}', 1); found += 1
        except FloodWaitError as e:
            log.warning(f'Поиск Telegram: пауза {e.seconds} с')
            if e.seconds > 120: break
            await asyncio.sleep(e.seconds)
        except Exception as e:
            log.warning(f'Поиск Telegram «{q}»: {e}')
        await asyncio.sleep(3)
    # уточняем найденные по ссылкам и упоминаниям (не больше 15 за раз — у Telegram жёсткие лимиты)
    rows = DBC.execute("SELECT id, handle FROM candidates WHERE kind='tg' AND resolved=0 AND status='new' ORDER BY id LIMIT 15").fetchall()
    for r in rows:
        try:
            e = await c.get_entity(r['handle'])
            if isinstance(e, types.User):
                DBC.execute('DELETE FROM candidates WHERE id=?', (r['id'],))
            else:
                full = await c(functions.channels.GetFullChannelRequest(e))
                DBC.execute('UPDATE candidates SET title=?, members=?, is_group=?, resolved=1 WHERE id=?',
                            (e.title, full.full_chat.participants_count or 0, int(bool(getattr(e, 'megagroup', False))), r['id']))
        except FloodWaitError as e:
            log.warning(f'Telegram: пауза {e.seconds} с, уточнение отложено'); break
        except Exception:
            DBC.execute('DELETE FROM candidates WHERE id=?', (r['id'],))
        await asyncio.sleep(4)
    DBC.commit()
    log.info(f'Поиск источников Telegram: найдено {found}, уточнено {len(rows)}')

# ---------- ВКонтакте ----------
async def vk_call(sess, method, **p):
    p = {k: str(v) for k, v in p.items()}
    p.update(access_token=CFG['vk_token'].strip(), v='5.199')
    async with sess.get(f'https://api.vk.com/method/{method}', params=p, timeout=aiohttp.ClientTimeout(total=30)) as r:
        j = await r.json(content_type=None)
    await asyncio.sleep(0.4)   # лимит VK: 3 запроса в секунду
    if 'error' in j: raise RuntimeError(j['error'].get('error_msg', 'ошибка VK'))
    return j['response']

def vk_owner(g):
    g = _norm_handle(g)
    m = re.match(r'^(?:club|public|event)?(\d+)$', g)
    return {'owner_id': '-' + m.group(1)} if m else {'domain': g}

def _vk_groups_map(r):
    return {-g['id']: g.get('name', '') for g in r.get('groups', [])}

async def vk_collect(sess):
    if not CFG['vk_token'].strip(): return
    saved = 0
    if CFG['vk_newsfeed']:
        for q in all_queries():
            key = 'vkq:' + q
            last = int(state_get(key, 0))
            try:
                r = await vk_call(sess, 'newsfeed.search', q=q, count=100, extended=1,
                                  start_time=(last + 1 if last else int(time.time()) - 3 * 86400))
                gm, mx = _vk_groups_map(r), last
                for it in r.get('items', []):
                    oid, pid, ts, txt = it.get('owner_id', 0), it.get('id'), it.get('date', 0), it.get('text', '')
                    mx = max(mx, ts)
                    title = gm.get(oid, 'Сообщество VK') if oid < 0 else 'Пользователь VK'
                    if save_item('vk', oid, title, f'https://vk.com/wall{oid}_{pid}', ts, txt, require_kw=False):
                        saved += 1; mine_links(txt)
                        if oid < 0: add_candidate('vk', f'club{-oid}', title, 0, 1, f'поиск: {q}')
                state_set(key, mx)
            except Exception as e:
                log.warning(f'VK поиск «{q}»: {e}')
        DBC.commit()
    for g in list(CFG['vk_groups']):
        key = 'vkg:' + _norm_handle(g)
        last = int(state_get(key, 0))
        try:
            r = await vk_call(sess, 'wall.get', count=50, extended=1, **vk_owner(g))
            gm, mx = _vk_groups_map(r), last
            for it in r.get('items', []):
                ts = it.get('date', 0)
                if ts <= last: continue
                mx = max(mx, ts)
                oid, txt = it.get('owner_id', 0), it.get('text', '')
                if save_item('vk', oid, gm.get(oid, g), f'https://vk.com/wall{oid}_{it.get("id")}', ts, txt):
                    saved += 1; mine_links(txt)
            state_set(key, mx)
        except Exception as e:
            log.warning(f'VK группа {g}: {e}')
        DBC.commit()
    log.info(f'ВКонтакте: сохранено по темам {saved}')

async def vk_discover(sess):
    if not CFG['vk_token'].strip(): return
    found = 0
    for q in discovery_queries():
        try:
            r = await vk_call(sess, 'groups.search', q=q, count=30)
            ids = [str(g['id']) for g in r.get('items', [])]
            if not ids: continue
            info = await vk_call(sess, 'groups.getById', group_ids=','.join(ids), fields='members_count')
            for g in (info.get('groups', []) if isinstance(info, dict) else info):
                add_candidate('vk', g.get('screen_name') or f'club{g["id"]}', g.get('name', ''), g.get('members_count', 0), 1, f'поиск: {q}', 1)
                found += 1
        except Exception as e:
            log.warning(f'Поиск групп VK «{q}»: {e}')
    # уточняем группы, найденные по ссылкам
    rows = DBC.execute("SELECT id, handle FROM candidates WHERE kind='vk' AND resolved=0 AND status='new' LIMIT 100").fetchall()
    if rows:
        try:
            info = await vk_call(sess, 'groups.getById', group_ids=','.join(r['handle'] for r in rows), fields='members_count')
            got = {}
            for g in (info.get('groups', []) if isinstance(info, dict) else info):
                got[(g.get('screen_name') or '').lower()] = g; got[f'club{g["id"]}'] = g
            for r in rows:
                g = got.get(r['handle'])
                if g: DBC.execute('UPDATE candidates SET title=?, members=?, resolved=1 WHERE id=?', (g.get('name', ''), g.get('members_count', 0), r['id']))
                else: DBC.execute('DELETE FROM candidates WHERE id=?', (r['id'],))
        except Exception as e:
            log.warning(f'Уточнение групп VK: {e}')
    DBC.commit()
    log.info(f'Поиск источников VK: найдено {found}')

# ---------- Google News и RSS ----------
async def news_collect(sess):
    feeds = []
    if CFG['google_news']:
        for q in all_queries():
            u = 'https://news.google.com/rss/search?' + urllib.parse.urlencode({'q': q + ' when:2d', 'hl': 'ru', 'gl': 'RU', 'ceid': 'RU:ru'})
            feeds.append(('news', q, u))
    feeds += [('rss', u, u) for u in CFG['rss'] if u.strip()]
    saved = 0
    for typ, label, url in feeds:
        try:
            async with sess.get(url.strip(), headers={'User-Agent': UA}, timeout=aiohttp.ClientTimeout(total=30)) as r:
                body = await r.read()
            f = feedparser.parse(body)
            ftitle = f.feed.get('title', label)
            for e in f.entries[:80]:
                ts = calendar.timegm(e.published_parsed) if e.get('published_parsed') else time.time()
                if ts < time.time() - 4 * 86400: continue
                title, summ = strip_html(e.get('title', '')), strip_html(e.get('summary', ''))
                txt = title if summ.startswith(title[:40]) else f'{title}. {summ}'
                src = (e.get('source') or {}).get('title') if typ == 'news' else ftitle
                if save_item(typ, label, src or ftitle, e.get('link', ''), ts, txt, require_kw=(typ == 'rss')): saved += 1
        except Exception as ex:
            log.warning(f'Лента {label[:60]}: {ex}')
        await asyncio.sleep(1)
    DBC.commit()
    log.info(f'Новости и RSS: сохранено {saved}')

# ---------- ИИ-разметка ----------
async def claude(sess, system, user, max_tokens=3000, model=None, tools=None):
    payload = {'model': model or CFG['model'], 'max_tokens': max_tokens, 'system': system,
               'messages': [{'role': 'user', 'content': user}]}
    if tools: payload['tools'] = tools
    async with sess.post('https://api.anthropic.com/v1/messages', json=payload,
                         headers={'x-api-key': CFG['anthropic_key'].strip(), 'anthropic-version': '2023-06-01'},
                         timeout=aiohttp.ClientTimeout(total=300)) as r:
        j = await r.json(content_type=None)
        if r.status != 200: raise RuntimeError((j.get('error') or {}).get('message', str(j))[:200])
    parts = []
    for b in j.get('content', []):
        if b.get('type') in ('server_tool_use', 'web_search_tool_result'): parts = []   # пояснения до поиска отбрасываем
        elif b.get('type') == 'text': parts.append(b.get('text', ''))
    text = ''.join(parts)
    if not text.strip(): raise RuntimeError(f'ИИ вернул пустой ответ (причина: {j.get("stop_reason")})')
    return text

def parse_json_array(s):
    s = s.strip().replace('```json', '').replace('```', '')
    a, b = s.find('['), s.rfind(']')
    if a >= 0 and b > a:
        try: return json.loads(s[a:b + 1])
        except Exception: pass
    out = []   # ответ обрезан или испорчен: спасаем каждый объект по отдельности
    for m in re.finditer(r'\{[^{}]*\}', s):
        try: out.append(json.loads(m.group(0)))
        except Exception: pass
    return out

def classify_system():
    names = '; '.join(t['name'] for t in CFG['topics'])
    return ('Ты аналитик медиамониторинга по экологии в России. Темы: ' + names + '.\n'
            'Для каждого сообщения #n верни объект JSON с полями: n (номер), rel (0..1 — насколько сообщение по существу '
            'относится к темам; реклама, шутки и случайные совпадения слов — низко), ru (true, если событие происходит в России '
            'или касается российской политики и регулирования; false для других стран), topic (одна из тем или «Другое»), '
            'region (субъект РФ или город; «РФ», если федеральный уровень; пусто, если неясно), '
            'kind (новость|жалоба|документ|событие|мнение|реклама|другое), sent (тональность от -1 до 1), '
            'imp (1..5: 5 — федеральные решения, крупные нарушения, массовые протесты, резонанс; 1 — малозначимо), '
            'sum (суть на русском, до 20 слов, без имён и контактов частных лиц). '
            'Ответь только JSON-массивом, без пояснений и без переносов строк внутри объектов.')

AI = {'error': '', 'done': 0}

async def classify(sess, batch_size=10):
    """Размечает одну пачку. Возвращает число размеченных или -1 при ошибке API."""
    rows = DBC.execute("SELECT id, src_title, text FROM items WHERE ai_status='pending' ORDER BY id DESC LIMIT ?", (batch_size,)).fetchall()
    if not rows: return 0
    payload = '\n\n'.join(f'#{n} [{r["src_title"]}]\n{r["text"][:1000]}' for n, r in enumerate(rows))
    try:
        arr = parse_json_array(await claude(sess, classify_system(), payload, max_tokens=4000))
        AI['error'] = ''
    except Exception as e:
        msg = str(e)
        if AI['error'] != msg: log.warning(f'ИИ-разметка: {msg}')
        AI['error'] = msg
        return -1
    byn = {}
    for a in arr:
        try: byn[int(a.get('n'))] = a
        except Exception: pass
    done = 0
    for n, r in enumerate(rows):
        a = byn.get(n)
        if not a:
            # не вернулся в ответе: даём ещё одну попытку, потом помечаем ошибкой
            tries = int(state_get(f'try:{r["id"]}', 0)) + 1
            state_set(f'try:{r["id"]}', tries)
            if tries >= 2: DBC.execute("UPDATE items SET ai_status='error' WHERE id=?", (r['id'],))
            continue
        def num(k, d):
            try: return float(a.get(k, d))
            except Exception: return d
        rel = num('rel', 0.5)
        if CFG.get('only_russia', True) and a.get('ru') is False: rel = min(rel, 0.1)
        DBC.execute("UPDATE items SET ai_status='done', relevance=?, topic=?, region=?, kind=?, sentiment=?, importance=?, summary=? WHERE id=?",
                    (rel, str(a.get('topic', ''))[:60], str(a.get('region', ''))[:60], str(a.get('kind', ''))[:20],
                     num('sent', 0), int(max(1, min(5, num('imp', 2)))), str(a.get('sum', ''))[:400], r['id']))
        done += 1
    DBC.commit()
    AI['done'] += done
    return done

async def classifier_loop():
    """Разметка идёт постоянно в фоне, независимо от сбора."""
    await asyncio.sleep(10)
    async with aiohttp.ClientSession() as s:
        while True:
            n = 0
            try:
                if CFG['anthropic_key'].strip(): n = await classify(s)
            except Exception as e:
                log.warning(f'ИИ-разметка: {e}'); n = -1
            if n > 0: await asyncio.sleep(1)
            elif n < 0: await asyncio.sleep(60)
            else: await asyncio.sleep(20)

# ---------- цикл ----------
STATUS = {'running': False, 'last_run': 0, 'stage': ''}
RUN_LOCK = asyncio.Lock()

async def cycle(force_discovery=False):
    if RUN_LOCK.locked(): return
    async with RUN_LOCK:
        STATUS['running'] = True
        try:
            async with aiohttp.ClientSession() as s:
                steps = [('Telegram', tg_collect), ('ВКонтакте', lambda: vk_collect(s)), ('Новости', lambda: news_collect(s))]
                last_disc = float(state_get('last_discovery', 0))
                if force_discovery or time.time() - last_disc > float(CFG['discovery_hours']) * 3600:
                    steps += [('Поиск источников Telegram', tg_discover), ('Поиск источников VK', lambda: vk_discover(s))]
                    state_set('last_discovery', time.time())
                for name, fn in steps:
                    STATUS['stage'] = name
                    try: await fn()
                    except Exception as e: log.exception(f'{name}: {e}')
                auto_approve()
            keep = int(CFG.get('keep_days') or 120)
            DBC.execute('DELETE FROM items WHERE ts < ?', (int(time.time()) - keep * 86400,))
            DBC.commit()
        finally:
            STATUS.update(running=False, last_run=time.time(), stage='')

async def scheduler():
    await asyncio.sleep(5)
    while True:
        try: await cycle()
        except Exception as e: log.exception(f'Цикл: {e}')
        await asyncio.sleep(max(5, int(CFG['interval_min'])) * 60)

# ---------- посты, бот, публикация ----------
FORMATS = {
    'news': ('Формат «Статья» (1200–2500 знаков) по одной теме:\n'
             '1) острый заголовок, раскрывающий суть проблемы;\n'
             '2) лид — 1–2 предложения, почему это касается читателя;\n'
             '3) что происходит: факты, цифры, хронология и контекст (кто регоператор, какие решения, какие тарифы и сроки);\n'
             '4) аргументы сторон: что говорят власти и компании, что говорят жители и эксперты;\n'
             '5) позиция ЧК: критический разбор — где нестыковки, кто недорабатывает, чем это оборачивается для людей;\n'
             '6) 2–3 прямых вопроса конкретным ответственным (губернатору, регоператору, Минприроды, Росприроднадзору, прокуратуре — кто уместен);\n'
             '7) короткая хлёсткая концовка.'),
    'analysis': ('Формат «Разбор» (2000–3500 знаков): заголовок; в чём проблема; как она устроена (законы, деньги, ответственные); '
                 'аргументы сторон из материалов; критическая оценка ЧК; что должно измениться; 2–3 вопроса ответственным.'),
    'digest': ('Формат «Главное за сутки»: заголовок и 3–5 тем. Каждая тема — отдельный абзац из 3–4 предложений: '
               'суть проблемы с фактами, критическая оценка и вопрос к ответственным. До 2500 знаков.'),
    'region': ('Формат «Регион под лупой» (1500–2500 знаков): что происходит в регионе, хронология, позиция властей, '
               'регоператора и жителей, критическая оценка ЧК, вопросы губернатору и другим ответственным.')}
FMT_NAMES = {'news': 'Статья', 'analysis': 'Разбор', 'digest': 'Главное за сутки', 'region': 'Регион под лупой'}
OUT_RULES = ('Пост — самостоятельный авторский материал канала, а не пересказ со ссылкой. Никаких ссылок, адресов сайтов, '
             'названий статей и фраз вида «читайте», «по ссылке», «подробнее в источнике». '
             'Чужие утверждения и обвинения подавай с указанием, чьи они, без ссылок: «по данным регионального издания», '
             '«как утверждают жители», «по информации ведомства». Свою позицию — как мнение канала. '
             'Не выдумывай факты, цифры и цитаты: используй только материалы и то, что нашёл поиском. '
             'Оформление — Telegram HTML: заголовок в <b></b>, допустимы только <b> и <i>. Последняя строка — 2–3 хэштега. '
             'Ответь только текстом поста.')
BOT = {'bind_code': '', 'rewrite_for': None, 'error': '', 'name': ''}

def clean_html(s):
    s = s.strip().replace('```html', '').replace('```', '').strip()
    s = re.sub(r'<br\s*/?>', '\n', s)
    def keep(m):
        t = m.group(0)
        return t if re.fullmatch(r'</?(b|i)>', t) else ''
    s = re.sub(r'<[^>]*>', keep, s)
    s = re.sub(r'\(?https?://[^\s<>()]+\)?', '', s)
    s = re.sub(r'[ \t]{2,}', ' ', s)
    return re.sub(r'&(?!amp;|lt;|gt;|quot;)', '&amp;', s)

def plain(s): return htmlmod.unescape(re.sub(r'<[^>]+>', '', s))

def tz(): return float(CFG.get('tz_offset') or 0) * 3600
def fmt_local(ts): return time.strftime('%d.%m в %H:%M', time.gmtime(ts + tz()))

def next_slot():
    taken = {r[0] for r in DBC.execute("SELECT sched_ts FROM posts WHERE status='scheduled'")}
    now = time.time()
    day0 = int((now + tz()) // 86400) * 86400 - tz()
    slots = sorted(s.strip() for s in CFG['slots'] if re.fullmatch(r'\d{1,2}:\d{2}', s.strip()))
    for d in range(60):
        for sl in slots:
            h, m = map(int, sl.split(':'))
            ts = int(day0 + d * 86400 + h * 3600 + m * 60)
            if ts > now + 60 and ts not in taken: return ts
    return int(now + 3600)

def materials(ids):
    if not ids: return ''
    rows = DBC.execute(f'SELECT * FROM items WHERE id IN ({",".join("?" * len(ids))})', ids).fetchall()
    return '\n\n'.join(f'[{n + 1}] {r["src_title"]} | {r["region"] or ""} | {r["summary"] or ""}\n{r["text"][:3000]}' for n, r in enumerate(rows))

SEARCH_TOOL = [{'type': 'web_search_20250305', 'name': 'web_search', 'max_uses': 4, 'user_location': {'type': 'approximate', 'country': 'RU'}}]

async def write(s, system, user, research=True):
    """Пишет пост. С поиском: модель находит полный текст и подробности новости. При сбое — без поиска и запасной моделью."""
    if research:
        system += ('\n\nПеред написанием найди поиском полные тексты этих новостей и подробности: позиции сторон, цифры, '
                   'предысторию, решения властей. Сделай не больше 4 поисков. Используй только найденные факты.')
    last = None
    plans = [(CFG.get('writer_model') or CFG['model'], research), (CFG.get('writer_model') or CFG['model'], False), (CFG['model'], False)]
    for m, use in plans:
        try:
            body = clean_html(await claude(s, system, user, max_tokens=8000, model=m, tools=SEARCH_TOOL if use else None))
            if plain(body).strip(): return body
            last = RuntimeError('ИИ вернул пустой текст')
        except Exception as e:
            last = e; log.warning(f'Пост, модель {m}{" с поиском" if use else ""}: {e}')
    raise last

async def generate_post(s, ids, fmt):
    if fmt not in FORMATS: fmt = 'news'
    if not ids and fmt == 'digest':
        ids = [r[0] for r in DBC.execute("SELECT id FROM items WHERE ts > ? AND ai_status='done' AND relevance >= 0.5 "
                                         "ORDER BY importance DESC, dups DESC LIMIT 8", (int(time.time()) - 86400,))]
    if not ids: raise RuntimeError('Не выбраны сообщения для поста')
    system = f'{CFG["post_style"]}\n\n{FORMATS[fmt]}\n{OUT_RULES}'
    body = await write(s, system, 'Материалы:\n\n' + materials(ids))
    cur = DBC.execute('INSERT INTO posts(item_ids, fmt, body, created) VALUES(?,?,?,?)', (json.dumps(ids), fmt, body, int(time.time())))
    for i in ids: state_set(f'drafted:{i}', 1)
    DBC.commit()
    return cur.lastrowid

async def rewrite_post(s, pid, instruction):
    r = DBC.execute('SELECT * FROM posts WHERE id=?', (pid,)).fetchone()
    system = f'{CFG["post_style"]}\n\n{FORMATS.get(r["fmt"], "")}\n{OUT_RULES}'
    mats = materials(json.loads(r['item_ids'] or '[]'))
    cur = r['body'] if plain(r['body'] or '').strip() else '(текста пока нет — напиши пост с нуля по материалам)'
    body = await write(s, system, f'Материалы:\n\n{mats}\n\nТекущий пост:\n{cur}\n\nПерепиши по указанию: {instruction}')
    DBC.execute("UPDATE posts SET body=?, status='draft' WHERE id=?", (body, pid)); DBC.commit()

async def bot(s, method, **p):
    tok = CFG['bot_token'].strip()
    if not tok: raise RuntimeError('Не задан токен бота')
    async with s.post(f'https://api.telegram.org/bot{tok}/{method}', json=p, timeout=aiohttp.ClientTimeout(total=60)) as r:
        j = await r.json(content_type=None)
    if not j.get('ok'): raise RuntimeError(j.get('description', 'ошибка Telegram'))
    return j['result']

async def bot_send(s, chat, text, **kw):
    try: return await bot(s, 'sendMessage', chat_id=chat, text=text, parse_mode='HTML', **kw)
    except RuntimeError as e:
        if 'parse' in str(e).lower() or 'entit' in str(e).lower():
            return await bot(s, 'sendMessage', chat_id=chat, text=plain(text), **kw)
        raise

async def send_for_approval(s, pid):
    if not (CFG['bot_token'].strip() and CFG['admin_chat']): return False
    r = DBC.execute('SELECT * FROM posts WHERE id=?', (pid,)).fetchone()
    kb = {'inline_keyboard': [[{'text': 'В очередь', 'callback_data': f'q:{pid}'}, {'text': 'Опубликовать сейчас', 'callback_data': f'n:{pid}'}],
                              [{'text': 'Переписать', 'callback_data': f'r:{pid}'}, {'text': 'Отклонить', 'callback_data': f'x:{pid}'}]]}
    await bot_send(s, CFG['admin_chat'], f'{r["body"]}\n\n<i>Черновик #{pid}, {FMT_NAMES.get(r["fmt"], "")}</i>', reply_markup=kb)
    return True

def schedule_post(pid):
    ts = next_slot()
    DBC.execute("UPDATE posts SET status='scheduled', sched_ts=? WHERE id=?", (ts, pid)); DBC.commit()
    return ts

async def publish_post(s, pid):
    if not CFG['channel'].strip(): raise RuntimeError('Не указан канал')
    r = DBC.execute('SELECT * FROM posts WHERE id=?', (pid,)).fetchone()
    m = await bot_send(s, CFG['channel'].strip(), r['body'])
    DBC.execute("UPDATE posts SET status='published', pub_ts=?, tg_msg_id=? WHERE id=?", (int(time.time()), m.get('message_id'), pid))
    DBC.commit()
    log.info(f'Пост #{pid} опубликован в канале')

async def bot_handle(s, u):
    admin = str(CFG.get('admin_chat') or '')
    if 'callback_query' in u:
        cq = u['callback_query']; chat = str(cq['message']['chat']['id'])
        if chat != admin: return
        act, pid = cq.get('data', 'x:0').split(':'); pid = int(pid)
        try:
            if act == 'q': msg = f'Пост #{pid} в очереди, выйдет {fmt_local(schedule_post(pid))}'
            elif act == 'n': await publish_post(s, pid); msg = f'Пост #{pid} опубликован'
            elif act == 'x': DBC.execute("UPDATE posts SET status='rejected' WHERE id=?", (pid,)); DBC.commit(); msg = f'Пост #{pid} отклонён'
            else: BOT['rewrite_for'] = pid; msg = f'Напишите следующим сообщением, что изменить в посте #{pid}'
        except Exception as e: msg = f'Ошибка: {e}'
        await bot(s, 'answerCallbackQuery', callback_query_id=cq['id'])
        if act != 'r':
            try: await bot(s, 'editMessageReplyMarkup', chat_id=chat, message_id=cq['message']['message_id'], reply_markup={'inline_keyboard': []})
            except Exception: pass
        await bot_send(s, chat, msg)
    elif 'message' in u:
        m = u['message']; chat = str(m['chat']['id']); text = (m.get('text') or '').strip()
        if text.startswith('/start'):
            code = text[6:].strip()
            if BOT['bind_code'] and code == BOT['bind_code']:
                CFG['admin_chat'] = chat; save_cfg(); BOT['bind_code'] = ''
                await bot_send(s, chat, 'Бот привязан. Сюда будут приходить черновики постов для согласования.')
            elif chat != admin:
                await bot_send(s, chat, 'Чтобы привязать бота, нажмите «Привязать бота» в панели и отправьте сюда /start с кодом.')
            return
        if chat == admin and BOT['rewrite_for'] and text:
            pid, BOT['rewrite_for'] = BOT['rewrite_for'], None
            await bot_send(s, chat, f'Переписываю пост #{pid}…')
            await rewrite_post(s, pid, text)
            await send_for_approval(s, pid)

async def bot_loop():
    await asyncio.sleep(8)
    async with aiohttp.ClientSession() as s:
        while True:
            if not CFG['bot_token'].strip(): await asyncio.sleep(15); continue
            try:
                ups = await bot(s, 'getUpdates', offset=int(state_get('bot_offset', 0)), timeout=25, allowed_updates=['message', 'callback_query'])
                for u in ups:
                    state_set('bot_offset', u['update_id'] + 1); DBC.commit()
                    try: await bot_handle(s, u)
                    except Exception as e: log.warning(f'Бот: {e}')
                BOT['error'] = ''
            except Exception as e:
                if BOT['error'] != str(e): log.warning(f'Бот: {e}')
                BOT['error'] = str(e); await asyncio.sleep(20)

async def publisher_loop():
    await asyncio.sleep(15)
    last_auto = 0
    async with aiohttp.ClientSession() as s:
        while True:
            try:
                if CFG['bot_token'].strip() and CFG['channel'].strip():
                    for r in DBC.execute("SELECT id FROM posts WHERE status='scheduled' AND sched_ts <= ?", (int(time.time()),)).fetchall():
                        try:
                            await publish_post(s, r['id'])
                            if CFG['admin_chat']: await bot_send(s, CFG['admin_chat'], f'Пост #{r["id"]} опубликован по расписанию')
                        except Exception as e:
                            log.warning(f'Публикация #{r["id"]}: {e}')
                            DBC.execute("UPDATE posts SET status='draft' WHERE id=?", (r['id'],)); DBC.commit()
                lim = int(CFG.get('auto_draft_imp') or 0)
                if lim > 0 and CFG['anthropic_key'].strip() and time.time() - last_auto > 600:
                    last_auto = time.time()
                    rows = DBC.execute("SELECT id FROM items WHERE ai_status='done' AND importance >= ? AND relevance >= 0.6 AND ts > ? "
                                       "AND topic IN (SELECT value FROM json_each(?)) "
                                       "ORDER BY importance DESC, dups DESC LIMIT 20",
                                       (lim, int(time.time()) - 86400, json.dumps([t['name'] for t in CFG['topics']]))).fetchall()
                    made = 0
                    dkey = 'auto:' + time.strftime('%Y-%m-%d', time.gmtime(time.time() + tz()))
                    today = int(state_get(dkey, 0))
                    for r in rows:
                        if made >= 3 or today + made >= int(CFG.get('auto_draft_per_day') or 8): break
                        if state_get(f'drafted:{r["id"]}'): continue
                        pid = await generate_post(s, [r['id']], 'news'); made += 1
                        await send_for_approval(s, pid)
                    if made: state_set(dkey, today + made); DBC.commit(); log.info(f'Автоматически подготовлено черновиков: {made}')
            except Exception as e:
                log.warning(f'Публикация: {e}')
            await asyncio.sleep(30)

# ---------- веб-API ----------
@web.middleware
async def auth(request, handler):
    if request.path.startswith('/api/'):
        if not TOKEN or request.headers.get('X-Token', '') != TOKEN:
            return web.json_response({'error': 'Неверный пароль'}, status=401)
    try:
        return await handler(request)
    except web.HTTPException: raise
    except Exception as e:
        log.warning(f'API {request.path}: {e}')
        return web.json_response({'error': str(e)}, status=400)

def masked(v): return ('••••' + v[-4:]) if v else ''

async def h_index(request):
    return web.FileResponse(os.path.join(BASE, 'dashboard.html'))

async def h_status(request):
    tg = 'нет ключей'
    if CFG['tg_api_id'] and CFG['tg_api_hash']:
        try:
            c = await tg_client()
            if await c.is_user_authorized():
                me = await c.get_me(); tg = f'подключён: {me.first_name or ""} {("@" + me.username) if me.username else ""}'.strip()
            else: tg = 'нужен вход'
        except Exception as e: tg = f'ошибка: {e}'
    q = lambda sql, *a: DBC.execute(sql, a).fetchone()[0]
    return web.json_response({
        'tg': tg, 'vk': bool(CFG['vk_token'].strip()), 'ai': bool(CFG['anthropic_key'].strip()),
        'running': STATUS['running'], 'stage': STATUS['stage'], 'ai_error': AI['error'], 'last_run': STATUS['last_run'],
        'items': q('SELECT COUNT(*) FROM items'), 'pending': q("SELECT COUNT(*) FROM items WHERE ai_status='pending'"),
        'day': q('SELECT COUNT(*) FROM items WHERE ts>?', int(time.time()) - 86400),
        'candidates': q("SELECT COUNT(*) FROM candidates WHERE status='new' AND resolved=1"),
        'sources': len(CFG['tg_sources']) + len(CFG['vk_groups']) + len(CFG['rss']),
        'topics': [t['name'] for t in CFG['topics']],
        'bot': {'token': bool(CFG['bot_token'].strip()), 'admin': bool(CFG['admin_chat']), 'channel': CFG['channel'], 'error': BOT['error']},
        'posts': {r[0]: r[1] for r in DBC.execute('SELECT status, COUNT(*) FROM posts GROUP BY status')}})

async def h_items(request):
    p = request.query
    days = float(p.get('days', 3))
    where, args = ['ts > ?'], [int(time.time() - days * 86400)]
    if p.get('all') != '1': where.append("(ai_status != 'done' OR relevance >= 0.4)")
    if p.get('topic'):
        where.append('(topic = ? OR (topic IS NULL AND kw LIKE ?))'); args += [p['topic'], f'%{p["topic"]}%']
    if p.get('imp'): where.append('COALESCE(importance, 2) >= ?'); args.append(int(p['imp']))
    if p.get('src'): where.append('src_type = ?'); args.append(p['src'])
    if p.get('region'): where.append('region LIKE ?'); args.append(f'%{p["region"]}%')
    if p.get('q'): where.append('(text LIKE ? OR summary LIKE ?)'); args += [f'%{p["q"]}%'] * 2
    order = 'COALESCE(importance,0) DESC, dups DESC, ts DESC' if p.get('sort') == 'imp' else 'ts DESC'
    lim, off = min(int(p.get('limit', 50)), 200), int(p.get('offset', 0))
    rows = DBC.execute(f'SELECT id,src_type,src_title,url,ts,text,kw,dups,ai_status,relevance,topic,region,kind,sentiment,importance,summary '
                       f'FROM items WHERE {" AND ".join(where)} ORDER BY {order} LIMIT ? OFFSET ?', args + [lim, off]).fetchall()
    drafted = {k for (k,) in DBC.execute("SELECT k FROM state WHERE k LIKE 'drafted:%'")}
    out = []
    for r in rows:
        d = dict(r); d['has_post'] = f'drafted:{r["id"]}' in drafted; out.append(d)
    return web.json_response(out)

async def h_stats(request):
    days = float(request.query.get('days', 14))
    since = int(time.time() - days * 86400)
    base = "FROM items WHERE ts > ? AND ai_status='done' AND relevance >= 0.4"
    f = lambda sql: [dict(r) for r in DBC.execute(sql, (since,)).fetchall()]
    return web.json_response({
        'by_day': f(f"SELECT date(ts,'unixepoch') d, COUNT(*) n {base} GROUP BY d ORDER BY d"),
        'by_topic': f(f'SELECT topic k, COUNT(*) n {base} GROUP BY topic ORDER BY n DESC'),
        'by_region': f(f"SELECT region k, COUNT(*) n, ROUND(AVG(sentiment),2) s {base} AND region != '' AND region != 'РФ' GROUP BY region ORDER BY n DESC LIMIT 20"),
        'by_kind': f(f'SELECT kind k, COUNT(*) n {base} GROUP BY kind ORDER BY n DESC'),
        'by_source': f(f'SELECT src_title k, COUNT(*) n {base} GROUP BY src_title ORDER BY n DESC LIMIT 15')})

async def h_cfg_get(request):
    c = dict(CFG)
    for k in SECRET_FIELDS: c[k] = masked(c.get(k, ''))
    return web.json_response(c)

async def h_cfg_post(request):
    body = await request.json()
    for k, v in body.items():
        if k not in DEFAULT_CONFIG: continue
        if k in SECRET_FIELDS and isinstance(v, str) and v.startswith('••••'): continue
        if isinstance(DEFAULT_CONFIG[k], list) and k != 'topics':
            v = [x.strip() for x in v if str(x).strip()] if isinstance(v, list) else [x.strip() for x in str(v).splitlines() if x.strip()]
        CFG[k] = v
    _kw_cache.clear(); save_cfg()
    return web.json_response({'ok': True})

async def h_tg_code(request):
    body = await request.json()
    c = await tg_client()
    if not c: return web.json_response({'error': 'Сначала сохраните api_id и api_hash'}, status=400)
    phone = re.sub(r'[^\d+]', '', body.get('phone', ''))
    r = await c.send_code_request(phone)
    TG['login'] = {'phone': phone, 'hash': r.phone_code_hash}
    return web.json_response({'ok': True})

async def h_tg_login(request):
    body = await request.json()
    c = await tg_client()
    if not c: return web.json_response({'error': 'Сначала сохраните api_id и api_hash в верхних полях'}, status=400)
    if not TG['login'] and str(body.get('code', '')).strip():
        return web.json_response({'error': 'Сначала введите номер и нажмите «Получить код»'}, status=400)
    code, pw = str(body.get('code', '')).strip(), body.get('password', '')
    try:
        if code:
            await c.sign_in(TG['login'].get('phone'), code, phone_code_hash=TG['login'].get('hash'))
        elif pw:
            await c.sign_in(password=pw)
    except SessionPasswordNeededError:
        if not pw: return web.json_response({'need_password': True})
        await c.sign_in(password=pw)
    ok = await c.is_user_authorized()
    if ok: log.info('Telegram: вход выполнен'); asyncio.create_task(cycle())
    return web.json_response({'ok': ok})

async def h_tg_logout(request):
    c = await tg_client()
    if c: await c.log_out()
    TG['client'] = None
    return web.json_response({'ok': True})

async def h_cands(request):
    p = request.query
    where, args = ["status = ?", 'resolved = 1'], [p.get('status', 'new')]
    if p.get('kind'): where.append('kind = ?'); args.append(p['kind'])
    rows = DBC.execute(f'SELECT * FROM candidates WHERE {" AND ".join(where)} ORDER BY members DESC LIMIT 300', args).fetchall()
    return web.json_response([dict(r) for r in rows])

async def h_cand_act(request):
    body = await request.json()
    ids = body.get('ids') or [body.get('id')]
    for cid in ids:
        if body.get('action') == 'approve': approve_candidate(int(cid))
        else: DBC.execute("UPDATE candidates SET status='rejected' WHERE id=?", (int(cid),))
    DBC.commit(); save_cfg()
    return web.json_response({'ok': True})

async def h_run(request):
    body = await request.json() if request.can_read_body else {}
    if STATUS['running']: return web.json_response({'ok': False, 'error': 'Сбор уже идёт'})
    asyncio.create_task(cycle(force_discovery=bool(body.get('discover'))))
    return web.json_response({'ok': True})

async def h_log(request):
    return web.json_response(list(LOG)[-200:])

async def h_posts(request):
    st = request.query.get('status', 'draft')
    order = 'sched_ts' if st == 'scheduled' else 'id DESC'
    rows = DBC.execute(f'SELECT * FROM posts WHERE status=? ORDER BY {order} LIMIT 100', (st,)).fetchall()
    out = []
    for r in rows:
        d = dict(r); d['fmt_name'] = FMT_NAMES.get(r['fmt'], r['fmt'])
        d['when'] = fmt_local(r['sched_ts']) if r['sched_ts'] else ''
        ch = CFG['channel'].strip().lstrip('@')
        d['link'] = f'https://t.me/{ch}/{r["tg_msg_id"]}' if r['tg_msg_id'] and ch and not ch.lstrip('-').isdigit() else ''
        out.append(d)
    return web.json_response(out)

async def h_post_generate(request):
    body = await request.json()
    ids = [int(i) for i in body.get('ids', [])]
    async with aiohttp.ClientSession() as s:
        pid = await generate_post(s, ids, body.get('fmt', 'news'))
        sent = False
        try: sent = await send_for_approval(s, pid)
        except Exception as e: log.warning(f'Бот: {e}')
    return web.json_response({'ok': True, 'id': pid, 'sent': sent})

async def h_post_action(request):
    b = await request.json()
    pid, act = int(b['id']), b.get('action')
    msg = ''
    async with aiohttp.ClientSession() as s:
        if act == 'save': DBC.execute('UPDATE posts SET body=? WHERE id=?', (clean_html(b.get('body', '')), pid))
        elif act == 'rewrite': await rewrite_post(s, pid, b.get('instruction', 'сделай лучше'))
        elif act == 'queue': msg = 'Выйдет ' + fmt_local(schedule_post(pid))
        elif act == 'now': await publish_post(s, pid); msg = 'Опубликовано'
        elif act == 'unqueue': DBC.execute("UPDATE posts SET status='draft', sched_ts=NULL WHERE id=?", (pid,))
        elif act == 'reject': DBC.execute("UPDATE posts SET status='rejected' WHERE id=?", (pid,))
        elif act == 'restore': DBC.execute("UPDATE posts SET status='draft' WHERE id=?", (pid,))
        elif act == 'bot': msg = 'Отправлено в бот' if await send_for_approval(s, pid) else 'Бот не привязан'
    DBC.commit()
    return web.json_response({'ok': True, 'msg': msg})

async def h_bot_bind(request):
    import secrets
    BOT['bind_code'] = str(secrets.randbelow(900000) + 100000)
    async with aiohttp.ClientSession() as s:
        me = await bot(s, 'getMe')
    return web.json_response({'code': BOT['bind_code'], 'bot': me.get('username', '')})

async def h_export(request):
    import csv, io
    p = request.query
    if p.get('ids'):
        ids = [int(i) for i in p['ids'].split(',') if i.strip().isdigit()]
        rows = DBC.execute(f'SELECT * FROM items WHERE id IN ({",".join("?" * len(ids))}) ORDER BY ts DESC', ids).fetchall() if ids else []
    else:
        rows = DBC.execute("SELECT * FROM items WHERE ts > ? AND (ai_status != 'done' OR relevance >= 0.4) ORDER BY ts DESC LIMIT 2000",
                           (int(time.time() - float(p.get('days', 3)) * 86400),)).fetchall()
    stamp = time.strftime('%Y-%m-%d', time.gmtime(time.time() + tz()))
    dt = lambda ts: time.strftime('%d.%m.%Y %H:%M', time.gmtime(ts + tz()))
    if p.get('fmt') == 'csv':
        buf = io.StringIO()
        w = csv.writer(buf, delimiter=';')
        w.writerow(['Дата', 'Источник', 'Тема', 'Регион', 'Тип', 'Важность', 'Суть', 'Текст', 'Ссылка'])
        for r in rows: w.writerow([dt(r['ts']), r['src_title'], r['topic'] or r['kw'], r['region'] or '', r['kind'] or '', r['importance'] or '', r['summary'] or '', r['text'], r['url']])
        return web.Response(body=('\ufeff' + buf.getvalue()).encode('utf-8'), content_type='text/csv',
                            headers={'Content-Disposition': f'attachment; filename="eco-{stamp}.csv"'})
    e = htmlmod.escape
    parts = [f'<h2>{e(r["summary"] or r["text"][:150])}</h2><p class="m">{e(dt(r["ts"]))}, {e(r["src_title"])}'
             f'{", " + e(r["region"]) if r["region"] else ""}{", важность " + str(r["importance"]) if r["importance"] else ""}</p>'
             f'<p>{e(r["text"])}</p><p><a href="{e(r["url"])}">{e(r["url"])}</a></p>' for r in rows]
    doc = (f'<!DOCTYPE html><html lang="ru"><meta charset="utf-8"><title>Подборка {stamp}</title><style>'
           'body{font:16px/1.55 Georgia,serif;max-width:46em;margin:2em auto;padding:0 1em}h2{font-size:18px;margin:1.6em 0 .2em}'
           '.m{color:#666;font-size:14px;margin:0}p{white-space:pre-wrap}</style>'
           f'<h1>Эко-Монитор: подборка от {stamp}</h1><p class="m">Сообщений: {len(rows)}</p>{"".join(parts)}</html>')
    return web.Response(body=doc.encode('utf-8'), content_type='text/html',
                        headers={'Content-Disposition': f'attachment; filename="eco-{stamp}.html"'})

async def h_update(request):
    import zipfile, io
    url = CFG.get('update_url', '').strip()
    async with aiohttp.ClientSession() as s:
        async with s.get(url, timeout=aiohttp.ClientTimeout(total=60)) as r:
            if r.status != 200: return web.json_response({'error': f'Архив не скачался: HTTP {r.status}'}, status=400)
            data = await r.read()
    z = zipfile.ZipFile(io.BytesIO(data))
    names = [n for n in z.namelist() if n in ('eco_monitor.py', 'dashboard.html')]
    if 'eco_monitor.py' not in names: return web.json_response({'error': 'В архиве нет eco_monitor.py'}, status=400)
    code = z.read('eco_monitor.py')
    compile(code, 'eco_monitor.py', 'exec')   # битый файл не ставим
    for n in names:
        with open(os.path.join(BASE, n + '.new'), 'wb') as f: f.write(z.read(n))
        os.replace(os.path.join(BASE, n + '.new'), os.path.join(BASE, n))
    log.info('Программа обновлена, перезапуск')
    asyncio.get_event_loop().call_later(1.5, lambda: os._exit(0))   # systemd перезапустит
    return web.json_response({'ok': True})

async def on_startup(app):
    app['sched'] = asyncio.create_task(scheduler())
    app['cls'] = asyncio.create_task(classifier_loop())
    app['bot'] = asyncio.create_task(bot_loop())
    app['pub'] = asyncio.create_task(publisher_loop())

def main():
    if not TOKEN: log.error('Не задан пароль ECO_TOKEN — панель будет недоступна')
    app = web.Application(middlewares=[auth])
    app.router.add_get('/', h_index)
    app.router.add_get('/api/status', h_status)
    app.router.add_get('/api/items', h_items)
    app.router.add_get('/api/stats', h_stats)
    app.router.add_get('/api/config', h_cfg_get)
    app.router.add_post('/api/config', h_cfg_post)
    app.router.add_post('/api/tg/code', h_tg_code)
    app.router.add_post('/api/tg/login', h_tg_login)
    app.router.add_post('/api/tg/logout', h_tg_logout)
    app.router.add_get('/api/candidates', h_cands)
    app.router.add_post('/api/candidates', h_cand_act)
    app.router.add_post('/api/run', h_run)
    app.router.add_get('/api/log', h_log)
    app.router.add_post('/api/update', h_update)
    app.router.add_get('/api/posts', h_posts)
    app.router.add_post('/api/posts/generate', h_post_generate)
    app.router.add_post('/api/posts/action', h_post_action)
    app.router.add_post('/api/bot/bind', h_bot_bind)
    app.router.add_get('/api/export', h_export)
    app.on_startup.append(on_startup)
    web.run_app(app, host=HOST, port=PORT, print=None)

if __name__ == '__main__':
    main()
