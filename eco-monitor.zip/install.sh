#!/bin/bash
# Установка Эко-Монитора. Запуск: bash install.sh ПАРОЛЬ_ПАНЕЛИ
P="$1"
cd /opt/eco
mkdir -p /opt/eco/data /etc/caddy /var/lib/caddy
printf 'ECO_TOKEN=%s\nECO_DATA=/opt/eco/data\n' "$P" > /opt/eco/env; chmod 600 /opt/eco/env
for i in 1 2 3; do python3 -m venv /opt/eco/venv && /opt/eco/venv/bin/pip install -q telethon aiohttp feedparser Pillow && break; sleep 15; done
cp /opt/eco/eco.service /opt/eco/caddy.service /etc/systemd/system/
A=$(dpkg --print-architecture)
for i in 1 2 3 4; do curl -fsSL "https://caddyserver.com/api/download?os=linux&arch=$A" -o /usr/local/bin/caddy && break; sleep 15; done
if [ ! -s /usr/local/bin/caddy ]; then
  U=$(curl -fsSL https://api.github.com/repos/caddyserver/caddy/releases/latest | grep -o "https://[^\"]*linux_$A.tar.gz" | head -1)
  curl -fsSL "$U" | tar -xz -C /usr/local/bin caddy
fi
chmod +x /usr/local/bin/caddy
IP=$(curl -fs http://169.254.169.254/hetzner/v1/metadata/public-ipv4 || curl -fs https://api.ipify.org)
H="$(echo "$IP" | tr . -).sslip.io"
printf '%s {\n  reverse_proxy 127.0.0.1:8080\n}\n' "$H" > /etc/caddy/Caddyfile
systemctl daemon-reload
if /usr/local/bin/caddy version; then
  systemctl enable --now caddy; echo "Панель: https://$H" > /root/ADDRESS.txt
else
  printf 'ECO_HOST=0.0.0.0\nECO_PORT=80\n' >> /opt/eco/env; echo "Панель: http://$IP" > /root/ADDRESS.txt
fi
systemctl enable --now eco
cat /root/ADDRESS.txt >> /etc/motd
echo ГОТОВО
